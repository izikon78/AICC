param([string]$Python="python")
& $Python (Join-Path $PSScriptRoot "scripts/setup.py")
exit $LASTEXITCODE
