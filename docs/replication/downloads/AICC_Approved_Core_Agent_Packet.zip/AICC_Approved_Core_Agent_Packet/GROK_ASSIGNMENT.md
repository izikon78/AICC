# Grok replication assignment

Perform the approved-core workflow theory replication in START_HERE.md Route A.
The original frozen experiment is experiments/approved_workflow_theory/.
Do not infer a target result from the theory. Reconstruct the documented counts
and Python rendering from the semantic inputs and pinned tokenizer, preserve
your first attempt, and only then compare. Use equal accounting opportunities
for AIN, readable IR and Python; do not add privileged operations to one form.

## Required evidence

- Provider, model/version as reported, date, operating system, Python and package
  versions; say whether identity is self-reported or externally recorded.
- Exact read order and any exposure to published results before sealing.
- SHA-256 hashes of the specification, trace inputs, workload source, tokenizer,
  independent implementation, first ledgers and first totals.
- Every semantic stage episode and every profile/request ledger row, in the
  frozen order. Include all inputs, outputs, memory and history recurrence.
- Execution and action/memory replay checks against the permitted oracle.
- Your original code and outputs even if wrong; corrections in a separate folder.
- Comparator exit code, first differing field if any, exact reference wrapper
  outcome, complete logs and any environmental or acquisition deviations.
- Actual provider usage when available. Missing authoring or experimental model
  telemetry stays unknown, not zero. Separate authoring-agent usage from the
  experiment's model_calls field.
- A critical assessment of the premises. Extensions must be separately versioned
  and must retain the frozen result rather than overwrite it.

## Important distinctions

The supplied traces already give correct actions. Replaying them tests accounting
and executable approved composition, not a model discovering a plan. Functions
and loops execute inside shared approved code. Resident and inspect schedules
reuse the same task families with different model-context exposure. They are not
independent populations or financial invoices.

If you have already read the article or totals, complete Route B and/or clearly
label your reconstruction as prior-exposed. Do not claim blinded independence.
The new article is intentionally stored under review-after-seal/.

## Return package

Fill GROK_SUBMISSION_TEMPLATE.json. Return a ZIP with your report, code, first
unmodified observations/seal, comparison, rerun logs and extension evidence.
Do not return .venv, cached duplicate assets, credentials or model weights.
The project owner will supply the result to the coordinating agent; you do not
need to publish or send messages to anyone else.
