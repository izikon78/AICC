# Start here for the approved-core replication

Research direction and concept: Izik Bachar. This packet is for Grok or another
AI agent to reproduce the latest approved-core workflow accounting experiment.
It is a CPU experiment. It does not train a model or require a GPU/model download.
No model weights, account credentials or API tokens are included.

## Choose the route before opening result-bearing files

### Route A Independent reconstruction

1. Record your agent/provider/model identity, environment and every file you read.
   If you have already seen reference totals or the new article, disclose that.
   A known-answer replay is useful but must not be called a blinded reconstruction.
2. Read GROK_ASSIGNMENT.md, then
   experiments/approved_workflow_theory/AGENT_START_HERE.md. Follow its required
   theory reading, including only pages 1-4 of the bundled Draft 8 PDF. Continue
   with REPLICATION_SPEC.md, AIN_LANGUAGE_AND_THEORY.md, trace-inputs.json,
   requirements-reproduce.txt and tokenizer-files.sha256.json. Consult only the
   expressly permitted workload interface before implementing your own counter.
3. Do not open accounting.py, run.py, report.py, reproduce.py, study README.md,
   ARTICLE_REPRODUCTION_BRIEF.md, results/, validation/ or review-after-seal/
   until your first implementation and complete ledgers are preserved and sealed.
   These files are retained at original paths so frozen package checks still work;
   their presence is not an instruction to read them early.
4. Write an independent counter/renderer, replay the supplied semantic actions,
   preserve your first totals.json and episodes.json with every per-request row,
   and record code/input/tokenizer/output hashes before comparing. Do not repair
   a mismatch by tuning to the expected numbers. Preserve the first attempt.
5. After sealing, run the frozen comparator, explain any earliest discrepancy,
   then use Route B for an exact reference-code environment check. Review the
   article and earlier agents only afterwards.

### Route B Exact reference rerun or known-answer verification

Read the study and its expected results openly, then use the setup commands below.
This checks frozen code and output compatibility. It is not independent authoring
or model learning. Keep failures and any deviations in separate output folders.

## Setup and bundled tokenizer

Python 3.12 is required for the reference environment. From this packet's root:

    python scripts/verify_packet.py
    python scripts/setup.py
    python scripts/run_reference.py --output work/grok-exact-001

On Windows, `py -3.12` may be used instead of `python` for the first two commands.
The setup helper creates .venv, installs the exact pinned Python requirements and
copies the bundled, hash-verified tokenizer assets into a private local cache.
The reference wrapper then runs with --offline. Internet is normally needed to
install the Python dependencies; this packet is not a complete offline Python
environment. No Hugging Face download is needed for the six bundled assets.

For an existing prepared environment, use:

    python scripts/setup.py --skip-install
    python scripts/prepare_cache.py

Record a deviation if your packages differ from the pins. Do not describe such
a run as the full exact pinned environment. Never substitute tokenizer bytes.

## What to return

Return your report, filled GROK_SUBMISSION_TEMPLATE.json, independent source,
first untouched ledgers and seal, comparison output, exact-rerun logs, environment
versions and all deviations. Zip your fresh work/ outputs; do not include .venv,
cache copies, credentials or model weights. Send the files back to the project
owner. No result is assumed in advance; pending Grok fields are ?? or null.

## Interpretation boundary

Python text-token counts are observed with the pinned tokenizer. Ideal code units
are modeled under learned-vocabulary, approved-core, correct-composition and
equal-cost-per-position premises. Ideal AIN, ideal IR and ideal Python receive
equal encoding opportunities. The test does not measure real model inference,
training, agent planning success, GPU time, power or monetary savings.

The packet snapshot and all payload hashes are in PACKET_MANIFEST.json. Its
source study is based on commit e9a8a5111717a57427fac50605cf5cbe0c86b316.
The new article and any display-code companion are under review-after-seal/;
they do not change the frozen measurement or its inputs.
