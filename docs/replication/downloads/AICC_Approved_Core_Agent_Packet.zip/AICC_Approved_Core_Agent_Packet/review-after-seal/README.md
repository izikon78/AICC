# Open only after the independent first seal

The article contains expected aggregates. Prior exposure must be disclosed.
Earlier agents and the reference result are also retained at their original
paths under experiments/approved_workflow_theory/results and validation so the
frozen package manifest and exact wrapper remain usable.
