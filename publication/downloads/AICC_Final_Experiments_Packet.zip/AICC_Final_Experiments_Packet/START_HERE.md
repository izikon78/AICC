# Final experiment packet

Read [the current standalone guide](publication/reproduction/START_HERE.md)
and select an independent reconstruction or exact replay route before
opening outcomes. Run its commands from this extracted root.

All final research files and asset hashes are in PACKET_MANIFEST.json.
Earlier article drafts are not required or included.
